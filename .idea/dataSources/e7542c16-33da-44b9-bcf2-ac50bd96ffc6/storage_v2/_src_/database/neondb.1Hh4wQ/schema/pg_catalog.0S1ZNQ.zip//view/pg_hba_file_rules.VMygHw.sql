create view pg_hba_file_rules (line_number, type, database, user_name, address, netmask, auth_method, options, error) as
SELECT a.line_number,
       a.type,
       a.database,
       a.user_name,
       a.address,
       a.netmask,
       a.auth_method,
       a.options,
       a.error
FROM pg_hba_file_rules() a(line_number, type, database, user_name, address, netmask, auth_method, options, error);

alter table pg_hba_file_rules
    owner to cloud_admin;

